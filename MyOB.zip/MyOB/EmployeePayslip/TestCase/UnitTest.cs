using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeePayslip;

namespace TestCase
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void TestMethodgetGrossMonthly()
        {
            double expected = 5000;
            Payslip test = new Payslip(60000);
            test.getGrossMonthly();
            double actual = test.getGrossMonthly();
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestMethodgetMonthlyTax()
        {
            double expected = 499.9750000000001;
            Payslip test = new Payslip(60000);
            test.getMonthlyTax();
            double actual = test.getMonthlyTax();
            Assert.AreEqual(expected, actual);
        }
        public void TestMethodgetNetMonthlyIncome()
        {
            double expected = 4500.025;
            Payslip test = new Payslip(60000);
            test.getNetMonthlyIncome();
            double actual = test.getNetMonthlyIncome();
            Assert.AreEqual(expected, actual);
        }

    }
}
