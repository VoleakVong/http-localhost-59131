﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmployeePayslip
{
    public class Tax
    {
        public Tax(double minimum, double maximum, double rateTax)
        {
            min = minimum;
            max = maximum;
            rate = rateTax;
        }
        public double min { get; set; }
        public double max { get; set; }
        public double rate { get; set; }
    }
    public class Payslip
    {
        public double min { get; set; }
        public double max { get; set; }
        public double rate { get; set; }

        private double salary;
        private Tax[] taxRate = {
                new Tax (0, 20000, 0.0),
                new Tax (20001, 40000, 0.1),
                new Tax (40001, 80000, 0.2),
                new Tax (80001, 180000, 0.3),
                new Tax (180001, 10000000, 0.4),
            };

        public Payslip(double salary)
        {
           
            this.salary = salary;
        }
        public double getGrossMonthly()
        {
            return this.salary / 12;
        }
        public double getMonthlyTax()
        {
            var monthlyTax = this.calculateTax(this.salary, 0) / 12;
            return monthlyTax;
        }
        public double getNetMonthlyIncome()
        {
            return this.getGrossMonthly() - this.getMonthlyTax();
        }

        public double calculateTax(double income, double taxTotal)
        {
            
            if (income <= 0.0)
            {
               
                return taxTotal;
            }
            else
            {
                Tax defineTaxRate = null;
                double afterTax = 0.0;
                

                foreach (Tax tax in taxRate)
                {
                    if (income >= tax.min && income <= tax.max)
                    {
                        defineTaxRate = tax;
                       
                    }
                }
                if (defineTaxRate != null)
                {

                    afterTax = ((income - defineTaxRate.min) * defineTaxRate.rate) + taxTotal;
                     
                    return this.calculateTax(defineTaxRate.min - 1, afterTax);
                }
                return afterTax;
            }
        }


    }
   
}
