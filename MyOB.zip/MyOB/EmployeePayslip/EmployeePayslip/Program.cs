﻿using System;

namespace EmployeePayslip
{
    class Program
    {
        static void Main(string[] args)
        {  
            Employee input = new Employee("voleak", 60000);
        }
    }
}
