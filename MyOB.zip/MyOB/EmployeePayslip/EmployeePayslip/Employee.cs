﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeePayslip
{
    class Employee : Payslip
    {
        string name;
        double salary;
        public Employee(String name, double salary) : base(salary)
        {
            this.name = name;
            this.salary = salary;

            Console.WriteLine("Monthly Payslip for:" + this.getName());
            Console.WriteLine("Monthly Payslip for:" + this.getGrossMonthly());
            Console.WriteLine("Monthly Income Tax: $" + this.getMonthlyTax());
            Console.WriteLine("Net Monthly Income: $" + this.getNetMonthlyIncome()); 
        }
        public string getName()
        {
            return this.name;
        }
        public double getSalary()
        {
            return this.salary;
        }

    }

}
